public class Rubik{

    int [][][] cube;
    Rubik(){}
    Rubik(int [][][] grid){
    
    
        this.cube = grid;

    
    }

    public Rubik viewRight(){
    
        int[][][] newcube = new int [6][3][3];

            int i =0;
          for(int face[][] : cube){

          
              if(i==0){
              newcube[i] = (new Face(face)).rotateRight().getGrid();

              }
              else if(i==1){
              
                  newcube[5]= (new Face(face)).rotateHalf().getGrid();

              
              }
              else if(i==2|| i ==3){
              
                  newcube[i-1] = (new Face(face)).getGrid();
              
              }
              else if( i == 4){
              
              
                  newcube[i] = (new Face(face)).rotateLeft().getGrid();
              
              }
              else if (i== 5){
              
                  newcube[3] =(new Face(face)).rotateHalf().getGrid();
              
              }

          
          
              i++;
          }

          return new Rubik(newcube);
    
    }


    public Rubik viewLeft(){

        return new Rubik();
    }


    public Rubik viewUp(){
    



        return new Rubik();

    
    
    
    }


    public Rubik viewDown(){
    
    
    return new Rubik();
    
    }


    @Override
    public String toString(){
    
    
    return "hi";

    }



}
